import { HazardCounts } from '../types';

export class LogicEngine {
  /**
   * Calculates the Hazard Score (S) based on the manifested formula.
   * S = ((0.50 * count_Risks) + (0.30 * count_Contradictions) + (0.20 * count_Actions)) / L
   * 
   * @param counts Raw counts from the LLM
   * @param wordCount Total word count of the document (or chunk)
   */
  static calculateHazardScore(counts: HazardCounts, wordCount: number): { score: number, level: 'SECURE' | 'CAUTION' | 'COMPROMISED' | 'HIGH_HAZARD' } {
    // Normalization Factor L
    // We assume a "standard" unit is about 500 words (1 page single spaced).
    // If the doc is shorter than 500 words, we treat L as 1 to avoid artificial inflation.
    const L = Math.max(1, wordCount / 500);

    const rawScore = (
      (0.50 * counts.risks) +
      (0.30 * counts.contradictions) +
      (0.20 * counts.actions)
    ) / L;

    // Convert raw density score to 0-100 scale.
    // A density of > 5 (e.g. 5 major risks per page) is considered catastrophic (100%).
    const MAX_DENSITY_THRESHOLD = 5; 
    let finalScore = (rawScore / MAX_DENSITY_THRESHOLD) * 100;
    
    finalScore = Math.min(100, Math.max(0, finalScore)); // Clamp

    let level: 'SECURE' | 'CAUTION' | 'COMPROMISED' | 'HIGH_HAZARD' = 'SECURE';

    if (finalScore > 80) level = 'HIGH_HAZARD';
    else if (finalScore > 50) level = 'COMPROMISED';
    else if (finalScore > 20) level = 'CAUTION';

    return { score: Math.round(finalScore), level };
  }
}
