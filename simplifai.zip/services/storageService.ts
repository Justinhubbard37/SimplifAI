import { FileMetadata } from '../types';

const ROOT_DIR = 'simplifai_data';
const INDEX_FILE = 'index.json';

export class StorageService {
  private static async getRoot() {
    const root = await navigator.storage.getDirectory();
    return root;
  }

  static async saveFile(file: File): Promise<string> {
    const root = await this.getRoot();
    const id = crypto.randomUUID();
    const fileHandle = await root.getFileHandle(id, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(file);
    await writable.close();

    // Update index
    await this.updateIndex({
      id,
      name: file.name,
      timestamp: Date.now(),
      size: file.size,
      type: file.type
    });

    return id;
  }

  static async getFile(id: string): Promise<File | null> {
    try {
      const root = await this.getRoot();
      const fileHandle = await root.getFileHandle(id);
      return await fileHandle.getFile();
    } catch (e) {
      console.error("File not found in OPFS", e);
      return null;
    }
  }

  static async updateIndex(entry: FileMetadata) {
    const root = await this.getRoot();
    let index: FileMetadata[] = [];
    
    try {
      const indexHandle = await root.getFileHandle(INDEX_FILE);
      const file = await indexHandle.getFile();
      const text = await file.text();
      index = JSON.parse(text);
    } catch (e) {
      // Index doesn't exist yet, start empty
    }

    index.push(entry);

    const indexHandle = await root.getFileHandle(INDEX_FILE, { create: true });
    const writable = await indexHandle.createWritable();
    await writable.write(JSON.stringify(index));
    await writable.close();
  }

  static async getHistory(): Promise<FileMetadata[]> {
    try {
      const root = await this.getRoot();
      const indexHandle = await root.getFileHandle(INDEX_FILE);
      const file = await indexHandle.getFile();
      const text = await file.text();
      return JSON.parse(text);
    } catch (e) {
      return [];
    }
  }
}
