import { GoogleGenAI, Type } from "@google/genai";
import { Inventory, AuditConfig, HazardCounts, DocumentType, AuditResult } from "../types";
import { LogicEngine } from "./logicEngine";

const getKey = () => localStorage.getItem("SIMPLIFAI_API_KEY") || "";

// --- Models ---
// Corrected: Use 3-flash for analysis (multimodal).
const MODEL_PRE_SCAN = "gemini-3-flash-preview"; 
const MODEL_SCRUTINY = "gemini-3-pro-preview";
const MODEL_CHAT = "gemini-3-flash-preview";
const MODEL_VIDEO = "veo-3.1-fast-generate-preview";

export class GeminiService {
  
  static async validateKey(key: string): Promise<boolean> {
    if (!key || key.length < 10) return false;
    
    try {
      const ai = new GoogleGenAI({ apiKey: key });
      
      // Create a timeout promise (30 seconds) to allow for thinking latency
      const timeout = new Promise<boolean>((_, reject) => 
        setTimeout(() => reject(new Error("Request timed out after 30s")), 30000)
      );

      // Create the API call promise with default configuration (preserving thinking budget)
      const apiCall = ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: "Ping",
      });

      // Race them
      await Promise.race([apiCall, timeout]);
      return true;
    } catch (e) {
      console.error("Key validation failed:", e);
      return false;
    }
  }

  // Helper to ensure clean JSON parsing
  private static parseJSON(text: string): any {
    try {
      // Remove code fences if present (```json ... ```)
      const clean = text.replace(/^```json\s*/, '').replace(/^```\s*/, '').replace(/```$/, '');
      return JSON.parse(clean);
    } catch (e) {
      console.error("Failed to parse JSON", text);
      return {};
    }
  }

  /**
   * Phase 1: Pre-Scan
   * Uses Gemini 3 Flash to quickly identify layout and type.
   */
  static async preScanDocument(file: File): Promise<Inventory> {
    const ai = new GoogleGenAI({ apiKey: getKey() });
    
    // Convert file to base64
    const base64Data = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        resolve(result.split(',')[1]);
      };
      reader.readAsDataURL(file);
    });

    const prompt = `
      Perform a visual inventory of this document. 
      Identify:
      1. Document Type (Financial Audit, Legal Contract, Technical Spec, Spreadsheet, Unknown).
      2. Estimated Page Count.
      3. Number of Charts/Graphs.
      4. Number of Tables.
      5. List 3 key potential risk indicators visible at a glance.
      
      Return JSON only.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_PRE_SCAN,
      contents: {
        parts: [
          { inlineData: { mimeType: file.type, data: base64Data } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            detectedType: { type: Type.STRING },
            pageCount: { type: Type.NUMBER },
            chartCount: { type: Type.NUMBER },
            tableCount: { type: Type.NUMBER },
            riskIndicators: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    });

    const data = this.parseJSON(response.text || "{}");
    
    // map string to enum
    let docType = DocumentType.UNKNOWN;
    const detected = data.detectedType?.toLowerCase() || "";
    if (detected.includes("financial")) docType = DocumentType.FINANCIAL_AUDIT;
    else if (detected.includes("contract") || detected.includes("legal")) docType = DocumentType.LEGAL_CONTRACT;
    else if (detected.includes("spec") || detected.includes("technical")) docType = DocumentType.TECHNICAL_SPEC;
    else if (detected.includes("sheet") || detected.includes("data")) docType = DocumentType.RAW_DATA;

    return {
      detectedType: docType,
      pageCount: data.pageCount || 1,
      chartCount: data.chartCount || 0,
      tableCount: data.tableCount || 0,
      riskIndicators: data.riskIndicators || []
    };
  }

  /**
   * Phase 2: Meticulous Scrutiny (Chunked)
   */
  static async performAudit(file: File, config: AuditConfig): Promise<AuditResult> {
    const textContent = await file.text(); // Assuming text-based extraction for now.
    
    // Chunking Logic (Limit ~20k chars per chunk to stay well under token limits)
    const CHUNK_SIZE = 20000; 
    const chunks = [];
    for (let i = 0; i < textContent.length; i += CHUNK_SIZE) {
      chunks.push(textContent.substring(i, i + CHUNK_SIZE));
    }

    let aggregatedCounts: HazardCounts = { risks: 0, contradictions: 0, actions: 0 };
    let aggregatedSummaryParts: string[] = [];
    let aggregatedAnnexParts: string[] = [];
    
    const ai = new GoogleGenAI({ apiKey: getKey() });

    // Process chunks recursively
    for (const chunk of chunks) {
        const result = await this.auditSingleChunk(ai, chunk, config);
        aggregatedCounts.risks += result.counts.risks;
        aggregatedCounts.contradictions += result.counts.contradictions;
        aggregatedCounts.actions += result.counts.actions;
        aggregatedSummaryParts.push(result.summary);
        if (result.annex) aggregatedAnnexParts.push(result.annex);
    }

    // Synthesize final report
    const wordCount = textContent.split(/\s+/).length;
    const { score, level } = LogicEngine.calculateHazardScore(aggregatedCounts, wordCount);

    // Final Synthesis Pass for Summary to make it cohesive
    const cohesiveSummary = await this.synthesizeSummaries(ai, aggregatedSummaryParts, config);
    const cohesiveAnnex = config.isDeepAudit && config.persona === "EXECUTIVE" 
      ? aggregatedAnnexParts.join("\n\n---\n\n") 
      : undefined;

    return {
      hazardScore: score,
      hazardLevel: level,
      counts: aggregatedCounts,
      summary: cohesiveSummary,
      auditAnnex: cohesiveAnnex
    };
  }

  private static async auditSingleChunk(ai: GoogleGenAI, text: string, config: AuditConfig): Promise<{ counts: HazardCounts, summary: string, annex?: string }> {
    const systemInstruction = `
      You are SimplifAI, a Zero-Trust Auditor.
      Role: ${config.persona}
      Mode: ${config.isDeepAudit ? "Deep Audit (Building Inspector)" : "Standard Summary"}
      
      Directives:
      1. Analyze the provided text chunk.
      2. Count distinct Risks, Contradictions, and Actions.
      3. CROSS-REFERENCE text with any tabular data present in the text.
      4. Output strict JSON with counts and a summary section.
      
      If Executive & Deep Audit: Provide a BLUF summary AND a detailed technical annex.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_SCRUTINY,
      contents: text,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            counts: {
              type: Type.OBJECT,
              properties: {
                risks: { type: Type.INTEGER },
                contradictions: { type: Type.INTEGER },
                actions: { type: Type.INTEGER }
              }
            },
            summary: { type: Type.STRING },
            annex: { type: Type.STRING }
          }
        }
      }
    });

    const json = this.parseJSON(response.text || "{}");
    return {
      counts: json.counts || { risks: 0, contradictions: 0, actions: 0 },
      summary: json.summary || "",
      annex: json.annex
    };
  }

  private static async synthesizeSummaries(ai: GoogleGenAI, summaries: string[], config: AuditConfig): Promise<string> {
    const combined = summaries.join("\n\n");
    const response = await ai.models.generateContent({
      model: MODEL_SCRUTINY,
      contents: `Synthesize these partial audit summaries into a single cohesive report formatted for a ${config.persona} persona. Keep it under ${config.persona === 'EXECUTIVE' ? '300 words' : '600 words'}.\n\n${combined}`,
    });
    return response.text || "";
  }

  /**
   * Chat Interaction (Grounded)
   */
  static async chat(message: string, history: any[], docContext: string): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: getKey() });
    
    const needsGrounding = message.toLowerCase().includes("check online") || message.toLowerCase().includes("verify");
    const model = needsGrounding ? MODEL_SCRUTINY : MODEL_CHAT;
    
    const chat = ai.chats.create({
      model: model,
      history: [
        { role: "user", parts: [{ text: `Context: You are analyzing this document:\n${docContext.substring(0, 20000)}... (truncated)` }] }, // Pass context
        ...history
      ],
      config: {
        tools: needsGrounding ? [{ googleSearch: {} }] : undefined
      }
    });

    const result = await chat.sendMessage(message);
    
    // Handle grounding sources if present
    let text = result.text;
    if (result.candidates?.[0]?.groundingMetadata?.groundingChunks) {
      const links = result.candidates[0].groundingMetadata.groundingChunks
        .map((c: any) => c.web?.uri)
        .filter((u: any) => u)
        .join(", ");
      if (links) text += `\n\nSources: ${links}`;
    }

    return text;
  }

  /**
   * Video Brief Generation
   */
  static async generateVideoBrief(summary: string): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: getKey() });
    
    try {
      let operation = await ai.models.generateVideos({
        model: MODEL_VIDEO,
        prompt: `A professional cinematic motion graphic summarizing: ${summary.substring(0, 100)}`,
        config: {
            numberOfVideos: 1,
            aspectRatio: '16:9',
            resolution: '720p'
        }
      });
      
      // Simple poll loop
      let attempts = 0;
      while (!operation.done && attempts < 20) {
        await new Promise(r => setTimeout(r, 2000));
        operation = await ai.operations.getVideosOperation({operation: operation});
        attempts++;
      }
      
      if (operation.response?.generatedVideos?.[0]?.video?.uri) {
         return `${operation.response.generatedVideos[0].video.uri}&key=${getKey()}`;
      }
      return "";
    } catch (e) {
      console.error("Video generation failed", e);
      return "";
    }
  }
}