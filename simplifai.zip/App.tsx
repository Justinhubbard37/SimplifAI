import React, { useState, useEffect } from 'react';
import { GeminiService } from './services/geminiService';
import { StorageService } from './services/storageService';
import { SecurityModal } from './components/SecurityModal';
import { PreviewModal } from './components/PreviewModal';
import { Dashboard } from './components/Dashboard';
import { AuditStatus, Inventory, AuditConfig, AuditResult } from './types';
import { Upload, Loader, FileText, ShieldCheck } from 'lucide-react';

const App: React.FC = () => {
  const [hasKey, setHasKey] = useState(false);
  const [status, setStatus] = useState<AuditStatus>(AuditStatus.IDLE);
  const [currentFile, setCurrentFile] = useState<File | null>(null);
  const [inventory, setInventory] = useState<Inventory | null>(null);
  const [auditResult, setAuditResult] = useState<AuditResult | null>(null);
  const [fileContent, setFileContent] = useState<string>('');

  useEffect(() => {
    const key = localStorage.getItem('SIMPLIFAI_API_KEY');
    if (key) setHasKey(true);
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setCurrentFile(file);
      setStatus(AuditStatus.PRE_SCANNING);
      
      // Save to OPFS
      await StorageService.saveFile(file);
      
      // Store text for chat context later (simplified for demo)
      const text = await file.text();
      setFileContent(text);

      // Phase 1: Pre-Scan
      try {
        const inv = await GeminiService.preScanDocument(file);
        setInventory(inv);
        setStatus(AuditStatus.REVIEW_READY);
      } catch (err) {
        console.error(err);
        setStatus(AuditStatus.ERROR);
      }
    }
  };

  const handleProceedToAudit = async (config: AuditConfig) => {
    if (!currentFile) return;
    setStatus(AuditStatus.AUDITING);
    try {
      const result = await GeminiService.performAudit(currentFile, config);
      setAuditResult(result);
      setStatus(AuditStatus.COMPLETE);
    } catch (err) {
      console.error(err);
      setStatus(AuditStatus.ERROR);
    }
  };

  if (!hasKey) {
    return <SecurityModal onComplete={() => setHasKey(true)} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-indigo-500/30">
      
      {/* Top Navigation */}
      <div className="h-16 border-b border-slate-800 flex items-center px-6 justify-between bg-slate-900/50 backdrop-blur-md fixed w-full z-40">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-tr from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <ShieldCheck className="text-white w-5 h-5" />
          </div>
          <span className="font-bold text-lg tracking-tight text-white">SimplifAI</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-xs text-slate-500 font-mono">SECURE_ENCLAVE::ACTIVE</span>
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
        </div>
      </div>

      <div className="pt-16 h-full">
        {status === AuditStatus.IDLE && (
          <div className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] p-6">
            <div className="max-w-xl w-full text-center space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight">
                  Zero-Trust Auditing.
                  <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
                    Local-First Intelligence.
                  </span>
                </h1>
                <p className="text-slate-400 text-lg">
                  Upload financial audits, legal contracts, or technical specs. 
                  SimplifAI scrutinizes every clause locally.
                </p>
              </div>

              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl blur opacity-25 group-hover:opacity-50 transition duration-200"></div>
                <div className="relative bg-slate-900 border border-slate-700 rounded-xl p-8 flex flex-col items-center gap-4 transition-transform group-hover:scale-[1.01]">
                  <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center">
                    <Upload className="w-8 h-8 text-indigo-400" />
                  </div>
                  <div className="text-center">
                    <label className="block text-white font-medium cursor-pointer hover:text-indigo-300 transition-colors">
                      <span className="underline decoration-indigo-500/50 underline-offset-4">Click to upload</span> or drag and drop
                      <input 
                        type="file" 
                        className="hidden" 
                        accept=".pdf,.txt,.md,.csv,.json"
                        onChange={handleFileUpload}
                      />
                    </label>
                    <p className="text-sm text-slate-500 mt-2">TXT, MD, CSV, JSON (PDF requires OCR logic, assume text-extracted for demo)</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {status === AuditStatus.PRE_SCANNING && (
          <div className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)]">
             <Loader className="w-12 h-12 text-indigo-500 animate-spin mb-6" />
             <h2 className="text-xl font-medium text-white">Performing Visual Pre-Scan...</h2>
             <p className="text-slate-500 mt-2">Identifying document topology and risk indicators.</p>
          </div>
        )}

        {status === AuditStatus.REVIEW_READY && inventory && (
          <PreviewModal 
            inventory={inventory} 
            onProceed={handleProceedToAudit} 
            onCancel={() => setStatus(AuditStatus.IDLE)} 
          />
        )}

        {status === AuditStatus.AUDITING && (
           <div className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] max-w-2xl mx-auto text-center px-4">
              <div className="relative w-24 h-24 mb-8">
                 <div className="absolute inset-0 border-4 border-indigo-500/20 rounded-full"></div>
                 <div className="absolute inset-0 border-4 border-indigo-500 rounded-full border-t-transparent animate-spin"></div>
                 <FileText className="absolute inset-0 m-auto w-8 h-8 text-indigo-400" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-4">Meticulous Scrutiny in Progress</h2>
              <div className="space-y-2 text-slate-400 text-sm font-mono">
                 <p className="animate-pulse">Analyzing text chunks...</p>
                 <p className="animate-pulse delay-100">Cross-referencing contradictions...</p>
                 <p className="animate-pulse delay-200">Calculating Hazard Score...</p>
              </div>
           </div>
        )}

        {status === AuditStatus.COMPLETE && auditResult && (
          <Dashboard result={auditResult} fileContext={fileContent} />
        )}
      </div>
    </div>
  );
};

export default App;
