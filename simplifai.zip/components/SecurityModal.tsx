import React, { useState, useEffect } from 'react';
import { GeminiService } from '../services/geminiService';
import { Shield, Key, AlertTriangle } from 'lucide-react';

interface Props {
  onComplete: () => void;
}

export const SecurityModal: React.FC<Props> = ({ onComplete }) => {
  const [key, setKey] = useState('');
  const [validating, setValidating] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    if (!key.trim()) return;
    
    setValidating(true);
    setError('');
    
    try {
      const isValid = await GeminiService.validateKey(key.trim());
      if (isValid) {
        localStorage.setItem('SIMPLIFAI_API_KEY', key.trim());
        // Do not update state here, as the component will unmount
        onComplete();
      } else {
        setError('Invalid API Key or Service Unreachable. Please verify your key and network.');
        setValidating(false);
      }
    } catch (e) {
      setError('An unexpected error occurred.');
      setValidating(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl p-8 max-w-md w-full shadow-2xl">
        <div className="flex flex-col items-center text-center mb-6">
          <div className="bg-blue-500/10 p-4 rounded-full mb-4">
            <Shield className="w-10 h-10 text-blue-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Secure Initialization</h2>
          <p className="text-slate-400 text-sm">
            SimplifAI operates on a Zero-Trust, Local-First architecture. 
            Your API key is stored locally in your browser and never sent to our servers.
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
              Gemini API Key
            </label>
            <div className="relative">
              <Key className="absolute left-3 top-3 w-5 h-5 text-slate-500" />
              <input
                type="password"
                value={key}
                onChange={(e) => setKey(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSave()}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg py-2.5 pl-10 pr-4 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                placeholder="AIza..."
              />
            </div>
          </div>

          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              {error}
            </div>
          )}

          <button
            onClick={handleSave}
            disabled={validating || !key}
            className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            {validating ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                <span>Validating...</span>
              </>
            ) : (
              <span>Initialize Secure Enclave</span>
            )}
          </button>

          <p className="text-xs text-center text-slate-600 mt-4">
            Get your key from Google AI Studio.
          </p>
        </div>
      </div>
    </div>
  );
};