import React, { useState } from 'react';
import { Inventory, AuditConfig, Persona, DocumentType } from '../types';
import { FileText, PieChart, AlertTriangle, Play, Settings } from 'lucide-react';

interface Props {
  inventory: Inventory;
  onProceed: (config: AuditConfig) => void;
  onCancel: () => void;
}

export const PreviewModal: React.FC<Props> = ({ inventory, onProceed, onCancel }) => {
  const [persona, setPersona] = useState<Persona>(Persona.GENERAL);
  const [isDeepAudit, setIsDeepAudit] = useState(false);
  const [isProductionTracker, setIsProductionTracker] = useState(inventory.detectedType === DocumentType.RAW_DATA);

  const handleSubmit = () => {
    onProceed({ persona, isDeepAudit, isProductionTracker });
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-2xl w-full shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-800/50 rounded-t-xl">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-500/10 p-2 rounded-lg">
              <FileText className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Review & Refine</h3>
              <p className="text-slate-400 text-xs uppercase tracking-wider">Phase 1: Ingestion Scan</p>
            </div>
          </div>
          <div className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-mono">
            {inventory.detectedType}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          
          {/* Visual Inventory */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50">
              <span className="text-slate-400 text-xs">Estimated Pages</span>
              <p className="text-2xl font-mono text-white mt-1">{inventory.pageCount}</p>
            </div>
            <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50">
              <span className="text-slate-400 text-xs">Charts & Tables</span>
              <p className="text-2xl font-mono text-white mt-1">{inventory.chartCount + inventory.tableCount}</p>
            </div>
            <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50">
              <span className="text-slate-400 text-xs">Risk Indicators</span>
              <p className="text-2xl font-mono text-red-400 mt-1">{inventory.riskIndicators.length}</p>
            </div>
          </div>

          {/* Configuration */}
          <div className="space-y-6">
            <div className="flex items-center gap-2 mb-4">
              <Settings className="w-5 h-5 text-slate-400" />
              <h4 className="text-white font-semibold">Audit Configuration</h4>
            </div>

            {/* Persona Selector */}
            <div className="space-y-3">
              <label className="text-sm text-slate-400">Select Auditor Persona</label>
              <div className="grid grid-cols-3 gap-3">
                {[Persona.EXECUTIVE, Persona.GENERAL, Persona.TECHNICAL].map((p) => (
                  <button
                    key={p}
                    onClick={() => setPersona(p)}
                    className={`p-3 rounded-lg border text-sm transition-all ${
                      persona === p
                        ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-[0_0_15px_rgba(99,102,241,0.3)]'
                        : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-750'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Scrutiny Slider */}
            <div className="bg-slate-800/30 p-4 rounded-xl border border-slate-700">
              <div className="flex items-center justify-between mb-4">
                <label className="text-sm text-white font-medium">Scrutiny Depth</label>
                <span className={`text-xs px-2 py-1 rounded border ${isDeepAudit ? 'bg-red-500/20 border-red-500/50 text-red-300' : 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'}`}>
                  {isDeepAudit ? 'DEEP AUDIT' : 'STANDARD SUMMARY'}
                </span>
              </div>
              <div 
                className="relative h-12 bg-slate-900 rounded-full p-1 cursor-pointer transition-all border border-slate-700"
                onClick={() => setIsDeepAudit(!isDeepAudit)}
              >
                <div 
                  className={`absolute top-1 bottom-1 w-1/2 rounded-full shadow-lg transition-all duration-300 flex items-center justify-center ${
                    isDeepAudit 
                      ? 'left-[49%] bg-gradient-to-r from-red-600 to-red-500' 
                      : 'left-1 bg-gradient-to-r from-emerald-600 to-emerald-500'
                  }`}
                >
                  <span className="text-xs font-bold text-white tracking-wider">
                    {isDeepAudit ? 'BUILDING INSPECTOR' : 'REPORTER'}
                  </span>
                </div>
              </div>
              <p className="text-xs text-slate-500 mt-3">
                {isDeepAudit 
                  ? "Activates meticulous scrutiny. Cross-references all visual data. High processing cost." 
                  : "Generates an objective summary. Good for quick overviews."}
              </p>
            </div>

            {/* Production Tracker Toggle (Conditional) */}
            {inventory.detectedType === DocumentType.RAW_DATA && (
               <div className="flex items-center gap-3 p-3 rounded-lg bg-blue-500/10 border border-blue-500/30">
                 <input 
                    type="checkbox" 
                    checked={isProductionTracker}
                    onChange={(e) => setIsProductionTracker(e.target.checked)}
                    className="w-4 h-4 rounded bg-slate-800 border-slate-600 text-blue-500"
                 />
                 <div>
                   <p className="text-sm text-white">Enable Production Tracker Dashboard</p>
                   <p className="text-xs text-slate-400">Visualize status rings and timelines.</p>
                 </div>
               </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-slate-800 flex justify-end gap-3 bg-slate-800/50 rounded-b-xl">
          <button 
            onClick={onCancel}
            className="px-6 py-3 rounded-lg text-slate-400 hover:text-white transition-colors text-sm font-medium"
          >
            Cancel
          </button>
          <button 
            onClick={handleSubmit}
            className="px-8 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-bold flex items-center gap-2 shadow-lg shadow-indigo-500/20 transition-all hover:scale-105"
          >
            <Play className="w-4 h-4 fill-current" />
            INITIATE PHASE 2
          </button>
        </div>
      </div>
    </div>
  );
};