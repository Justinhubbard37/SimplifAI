import React, { useState, useEffect } from 'react';
import { AuditResult, ChatMessage } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { GeminiService } from '../services/geminiService';
import { Send, Download, Video, AlertOctagon, CheckCircle, AlertTriangle, FileText } from 'lucide-react';
import jsPDF from 'jspdf';

interface Props {
  result: AuditResult;
  fileContext: string; // The raw text for context
}

export const Dashboard: React.FC<Props> = ({ result, fileContext }) => {
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [generatingVideo, setGeneratingVideo] = useState(false);

  // Score Data for Gauge
  const scoreData = [
    { name: 'Hazard', value: result.hazardScore },
    { name: 'Safe', value: 100 - result.hazardScore }
  ];
  const scoreColor = 
    result.hazardLevel === 'HIGH_HAZARD' ? '#ef4444' :
    result.hazardLevel === 'COMPROMISED' ? '#f97316' :
    result.hazardLevel === 'CAUTION' ? '#eab308' : '#10b981';

  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;
    
    const userMsg: ChatMessage = { role: 'user', content: chatInput, timestamp: Date.now() };
    setChatHistory(prev => [...prev, userMsg]);
    setChatInput('');
    setIsTyping(true);

    try {
      // Format history for API
      const apiHistory = chatHistory.map(m => ({
        role: m.role,
        parts: [{ text: m.content }]
      }));

      const responseText = await GeminiService.chat(userMsg.content, apiHistory, fileContext);
      
      const botMsg: ChatMessage = { role: 'model', content: responseText, timestamp: Date.now() };
      setChatHistory(prev => [...prev, botMsg]);
    } catch (e) {
      console.error(e);
    } finally {
      setIsTyping(false);
    }
  };

  const generatePDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text("SimplifAI Audit Report", 20, 20);
    
    doc.setFontSize(12);
    doc.text(`Hazard Score: ${result.hazardScore} / 100 (${result.hazardLevel})`, 20, 35);
    doc.text(`Risks: ${result.counts.risks} | Contradictions: ${result.counts.contradictions}`, 20, 45);
    
    doc.setFontSize(14);
    doc.text("Executive Summary", 20, 60);
    
    doc.setFontSize(10);
    const splitSummary = doc.splitTextToSize(result.summary, 170);
    doc.text(splitSummary, 20, 70);
    
    if (result.auditAnnex) {
        doc.addPage();
        doc.setFontSize(14);
        doc.text("Audit Annex (Deep Audit)", 20, 20);
        doc.setFontSize(10);
        const splitAnnex = doc.splitTextToSize(result.auditAnnex, 170);
        doc.text(splitAnnex, 20, 30);
    }
    
    doc.save("simplifai-report.pdf");
  };

  const handleVideoGen = async () => {
    setGeneratingVideo(true);
    const url = await GeminiService.generateVideoBrief(result.summary);
    if (url) setVideoUrl(url);
    setGeneratingVideo(false);
  };

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden">
      
      {/* Left: Metrics & Findings */}
      <div className="w-1/2 p-8 overflow-y-auto border-r border-slate-800 space-y-8">
        
        {/* Header Block */}
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-white tracking-tight">Audit Dashboard</h1>
            <p className="text-slate-400 mt-1">Status: <span className="text-emerald-400">Analysis Complete</span></p>
          </div>
          <button onClick={generatePDF} className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300 transition-colors">
            <Download className="w-5 h-5" />
          </button>
        </div>

        {/* Hazard Score Card */}
        <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 relative overflow-hidden">
          <div className="flex items-center gap-8">
            <div className="w-32 h-32 relative">
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                   <Pie
                     data={scoreData}
                     innerRadius={40}
                     outerRadius={55}
                     startAngle={90}
                     endAngle={-270}
                     dataKey="value"
                     stroke="none"
                   >
                     <Cell fill={scoreColor} />
                     <Cell fill="#1e293b" />
                   </Pie>
                 </PieChart>
               </ResponsiveContainer>
               <div className="absolute inset-0 flex items-center justify-center flex-col">
                 <span className="text-3xl font-bold text-white">{result.hazardScore}</span>
                 <span className="text-[10px] text-slate-500 uppercase">Score</span>
               </div>
            </div>
            
            <div className="flex-1 space-y-4">
              <div>
                <h3 className="text-sm font-medium text-slate-400 uppercase tracking-wider">Hazard Level</h3>
                <p className="text-2xl font-bold" style={{ color: scoreColor }}>{result.hazardLevel.replace('_', ' ')}</p>
              </div>
              
              <div className="flex gap-4">
                <div className="bg-slate-950/50 p-2 rounded flex items-center gap-2 border border-slate-800">
                    <AlertOctagon className="w-4 h-4 text-red-500" />
                    <span className="text-white font-mono">{result.counts.risks}</span>
                    <span className="text-xs text-slate-500">Risks</span>
                </div>
                <div className="bg-slate-950/50 p-2 rounded flex items-center gap-2 border border-slate-800">
                    <AlertTriangle className="w-4 h-4 text-orange-500" />
                    <span className="text-white font-mono">{result.counts.contradictions}</span>
                    <span className="text-xs text-slate-500">Contradictions</span>
                </div>
                <div className="bg-slate-950/50 p-2 rounded flex items-center gap-2 border border-slate-800">
                    <CheckCircle className="w-4 h-4 text-blue-500" />
                    <span className="text-white font-mono">{result.counts.actions}</span>
                    <span className="text-xs text-slate-500">Actions</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Summary Section */}
        <div className="space-y-4">
            <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                    <FileText className="w-5 h-5 text-indigo-400" />
                    Executive Summary
                </h3>
                <button 
                  onClick={handleVideoGen} 
                  disabled={generatingVideo}
                  className="flex items-center gap-2 text-xs bg-purple-600/20 text-purple-300 px-3 py-1 rounded hover:bg-purple-600/30 transition-colors"
                >
                    <Video className="w-3 h-3" />
                    {generatingVideo ? 'Generating...' : 'Generate Video Brief'}
                </button>
            </div>
            
            {videoUrl && (
                <div className="aspect-video bg-black rounded-lg overflow-hidden border border-slate-700">
                    <video src={videoUrl} controls className="w-full h-full" />
                </div>
            )}

            <div className="bg-slate-900/50 p-6 rounded-xl border border-slate-800 text-slate-300 leading-relaxed text-sm">
                {result.summary}
            </div>
        </div>

        {/* Audit Annex (Conditional) */}
        {result.auditAnnex && (
            <div className="space-y-4">
                 <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                    Deep Audit Annex
                </h3>
                <div className="bg-black/40 p-6 rounded-xl border border-red-900/20 text-slate-400 text-sm font-mono whitespace-pre-wrap h-96 overflow-y-auto">
                    {result.auditAnnex}
                </div>
            </div>
        )}

      </div>

      {/* Right: Chat Interface */}
      <div className="w-1/2 flex flex-col border-l border-slate-800 bg-slate-900/30">
        <div className="p-4 border-b border-slate-800 bg-slate-900">
            <h3 className="font-semibold text-white">Auditor Interaction</h3>
            <p className="text-xs text-slate-500">Ask follow-up questions or verify grounding.</p>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {chatHistory.map((msg, idx) => (
                <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-4 rounded-2xl text-sm ${
                        msg.role === 'user' 
                        ? 'bg-blue-600 text-white rounded-br-none' 
                        : 'bg-slate-800 text-slate-200 rounded-bl-none border border-slate-700'
                    }`}>
                        <p className="whitespace-pre-wrap">{msg.content}</p>
                    </div>
                </div>
            ))}
            {isTyping && (
                <div className="flex justify-start">
                    <div className="bg-slate-800 p-4 rounded-2xl rounded-bl-none border border-slate-700">
                        <div className="flex gap-1">
                            <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce"></span>
                            <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce delay-75"></span>
                            <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce delay-150"></span>
                        </div>
                    </div>
                </div>
            )}
        </div>

        <div className="p-4 border-t border-slate-800 bg-slate-900">
            <div className="relative">
                <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Ask about risks, specific clauses, or contradictions..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-3 pl-4 pr-12 text-white focus:outline-none focus:border-indigo-500 transition-colors"
                />
                <button 
                    onClick={handleSendMessage}
                    disabled={!chatInput.trim() || isTyping}
                    className="absolute right-2 top-2 p-1.5 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-white transition-colors disabled:opacity-50"
                >
                    <Send className="w-4 h-4" />
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};
