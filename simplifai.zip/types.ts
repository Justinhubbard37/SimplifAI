export enum AuditStatus {
  IDLE = 'IDLE',
  PRE_SCANNING = 'PRE_SCANNING',
  REVIEW_READY = 'REVIEW_READY',
  AUDITING = 'AUDITING',
  COMPLETE = 'COMPLETE',
  ERROR = 'ERROR'
}

export enum Persona {
  EXECUTIVE = 'EXECUTIVE',
  TECHNICAL = 'TECHNICAL',
  GENERAL = 'GENERAL'
}

export enum DocumentType {
  FINANCIAL_AUDIT = 'Financial Audit',
  LEGAL_CONTRACT = 'Legal Contract',
  TECHNICAL_SPEC = 'Technical Specification',
  RAW_DATA = 'Raw Data Spreadsheet',
  UNKNOWN = 'Unknown Document'
}

export interface Inventory {
  detectedType: DocumentType;
  pageCount: number; // Estimated
  chartCount: number;
  tableCount: number;
  riskIndicators: string[];
}

export interface AuditConfig {
  persona: Persona;
  isDeepAudit: boolean;
  isProductionTracker: boolean;
}

export interface HazardCounts {
  risks: number;
  contradictions: number;
  actions: number;
}

export interface AuditResult {
  hazardScore: number; // 0-100
  hazardLevel: 'SECURE' | 'CAUTION' | 'COMPROMISED' | 'HIGH_HAZARD';
  counts: HazardCounts;
  summary: string;
  auditAnnex?: string; // Only for Deep Audit + Executive
  productionData?: any[]; // For spreadsheet mode
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  timestamp: number;
}

export interface FileMetadata {
  id: string;
  name: string;
  timestamp: number;
  size: number;
  type: string;
}
